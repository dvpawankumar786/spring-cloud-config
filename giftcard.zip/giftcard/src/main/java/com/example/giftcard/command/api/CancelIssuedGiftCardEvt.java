package com.example.giftcard.command.api;

import java.util.UUID;

import lombok.Value;

@Value
public class CancelIssuedGiftCardEvt {

	 UUID id;
}
