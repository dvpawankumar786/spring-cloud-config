package com.example.giftcard.query;

import java.util.UUID;

import lombok.NoArgsConstructor;
@NoArgsConstructor
	public class GfitCardAllDataQuery {

		UUID id;
	}

