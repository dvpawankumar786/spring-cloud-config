package com.example.giftcard.query;


public class EventProcessorConfig {

	  
	    public void config() {
		  
		   }
	       
		  
}
