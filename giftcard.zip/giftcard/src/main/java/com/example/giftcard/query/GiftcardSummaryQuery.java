package com.example.giftcard.query;

import lombok.Value;

import java.util.UUID;

@Value
public class GiftcardSummaryQuery {

    UUID id;

}
